package com.example.proyectogoldentrio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class UserBlockeds : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_blockeds)
    }
}